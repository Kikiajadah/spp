<?php
include 'koneksi.php';
include 'fungsi.php';

if (isset($_GET['page']) && !isset($_SESSION['login'])) {
	header('Location: index.php');
	exit;
} else if (!isset($_GET['page']) && isset($_SESSION['login'])) {
	header('Location: index.php?page=home');
	exit;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
	<title>SPP APP</title>
	<!-- Required meta tags -->
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

	<!-- Google Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap" rel="stylesheet">

	<!-- Bootstrap CSS v5.2.1 -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous" />
	<link href="assets/css/style.css" rel="stylesheet">

	<!-- Bootstrap Icons -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>

<body>
	<header>
		<nav class="navbar navbar-expand-lg navbar-dark">
			<div class="container">
				<a class="navbar-brand" href="./">
					<img src="assets/img/ubuntu.png" class="shadow rounded-circle" width="40" alt="ubuntu logo">
					<span class="text-white ms-2">SPP APP</span>
				</a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
					<div class="navbar-nav<?= !isset($_SESSION['login']) ? ' ms-auto' : '' ?>">
						<?php if (isset($_SESSION['login'])) : ?>
							<a class="nav-link text-white" href="<?= BASE_URL . '/index.php?page=home' ?>">Beranda</a>
							<?php if ($_SESSION['level'] == 'admin') : ?>
							<a class="nav-link text-white" href="<?= BASE_URL . '/index.php?page=siswa' ?>">Siswa</a>
							<a class="nav-link text-white" href="<?= BASE_URL . '/index.php?page=admin' ?>">Admin</a>
							<a class="nav-link text-white" href="<?= BASE_URL . '/index.php?page=spp' ?>">SPP</a>
							<?php endif ?>
							<a class="nav-link text-white" href="<?= BASE_URL . '/index.php?page=transaksi' ?>">Transaksi</a>
							<a class="nav-link text-white" href="<?= BASE_URL . '/index.php?page=logout' ?>" onclick="return confirm('Ingin Logout?')">Logout</a>
						<?php else : ?>
							<a class="nav-link text-white" href="./">Login</a>
						<?php endif ?>
					</div>
				</div>
			</div>
		</nav>
	</header>

	<main>
		<?php
		$page = isset($_GET['page']) ? $_GET['page'] : '';

		switch ($page) {
			case 'home':
				include 'home/index.php';
				break;
			case 'siswa':
				include 'siswa/index.php';
				break;
			case 'tambah_siswa':
				include 'siswa/tambah.php';
				break;
			case 'hapus_siswa':
				include 'siswa/hapus.php';
				break;
			case 'edit_siswa':
				include 'siswa/edit.php';
				break;
			case 'admin':
				include 'admin/index.php';
				break;
			case 'tambah_admin':
				include 'admin/tambah.php';
				break;
			case 'hapus_admin':
				include 'admin/hapus.php';
				break;
			case 'spp':
				include 'spp/index.php';
				break;
			case 'tambah_spp':
				include 'spp/tambah.php';
				break;
			case 'hapus_spp':
				include 'spp/hapus.php';
				break;
			case 'edit_spp':
				include 'spp/edit.php';
				break;
			case 'transaksi':
				include 'transaksi/index.php';
				break;
			case 'tambah_transaksi':
				include 'transaksi/tambah.php';
				break;
			case 'hapus_transaksi':
				include 'transaksi/hapus.php';
				break;
			case 'laporan_transaksi':
				include 'transaksi/laporan.php';
				break;
			case 'logout':
				include 'auth/logout.php';
				break;
			default:
				include 'auth/login.php';
		}
		?>
	</main>

	<footer>
		<!-- place footer here -->
	</footer>
	<!-- Bootstrap JavaScript Libraries -->
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>
</body>

</html>