<?php

hapus_data('siswa','nisn=' . $_GET['nisn']);

set_flash('success', 'Siswa berhasil dihapus');
back();