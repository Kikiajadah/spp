<?php
$siswa = mysqli_fetch_assoc(tampil_data('siswa',null,'nisn='. $_GET['nisn']));


$kelas = tampil_data('kelas');
$spp = tampil_data('spp');
if (isset($_POST['simpan'])) {
	
 

	$tambah = update_data('siswa', [
		'nisn' => post('nisn'),
    'nis' => post('nis'),
		'nama_siswa' => post('siswa'),
    'email' => post('email'),
		'password' => password_hash (post('password'), PASSWORD_DEFAULT),
    'pasword_nohash' => post('password'),
		'id_kelas' => post('kelas'),
    'alamat' => post('alamat'),
    'no_telp' => post('no_telp'),
    'id_spp' => post('spp')
	],'nisn='. $_GET['nisn']);


	set_flash('success', 'Siswa berhasil ditambahkan');
	header('Location: index.php?page=siswa');
	exit;
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT"
      crossorigin="anonymous"
    />
  </head>

  <body>
    
    <main>
      <div class="container mt-5 mb-5">
        <div class="row justify-content-center">
          <div class="col-lg-6">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Tambah Siswa</h4>
                <form method="POST">
                  <div class="mb-3">
                    <label for="" class="form-label">NISN</label>
                    <input
                    value="<?=$siswa['nisn'] ?>"
                      type="number"
                      class="form-control"
                      name="nisn"
                      id="nisn"
                      aria-describedby="helpId"
                      placeholder=""
                    />
                  </div>
                  <div class="mb-3">
                    <label for="" class="form-label">NIS</label>
                    <input
                    value="<?=$siswa['nis'] ?>"
                      type="number"
                      class="form-control"
                      name="nis"
                      id="nis"
                      aria-describedby="helpId"
                      placeholder=""
                    />
                  </div>


                  <div class="mb-3">
                    <label for="" class="form-label">Nama Siswa</label>
                    <input
                    value="<?=$siswa['nama_siswa'] ?>"
                      type="text"
                      class="form-control"
                      name="siswa"
                      id="siswa"
                      placeholder=""
                    />
                  </div>
                  <div class="mb-3">
                    <label for="" class="form-label">password</label>
                    <input
                    value="<?=$siswa['password'] ?>"
                      type="password"
                      class="form-control"
                      name="password"
                      id="password"
                      placeholder=""
                    />
                  </div>
                  <div class="mb-3">
                    <label for="" class="form-label">Email</label>
                    <input
                    value="<?=$siswa['email'] ?>"
                      type="text"
                      class="form-control"
                      name="email"
                      id="email"
                      placeholder=""
                    />
                  </div>
					
						<div class="mb-3">
							<label for="kelas" class="form-label">Kelas</label>
							<select class="form-select <?= has_error('kelas') ? 'is-invalid' : '' ?>" name="kelas" id="kelas">
								<option value="" hidden>Pilih Kelas</option>
								<?php foreach ($kelas as $k) : ?>
									<option value="<?= $k['id_kelas'] ?>" > <?= $k['nama_kelas'] ?> <?= $k['kompetesi_keahlian'] ?></option>
								<?php endforeach ?>
							</select>
							<div class="invalid-feedback"><?= error('kelas') ?></div>
						</div>

                  <div class="mb-3">
                    <label for="" class="form-label">No. Telepon</label>
                    <input value="<?=$siswa['no_telp'] ?>" type="text" class="form-control" name="no_telp" id="no_telp" placeholder="">
                  </div>

                  <div class="mb-3">
                    <label for="" class="form-label">Alamat</label>
                    <textarea class="form-control" name="alamat" id="alamat" rows="3"><?=$siswa['alamat'] ?></textarea>
                  </div>
                  <div class="mb-3">
							<label for="spp" class="form-label">Tahun ajaran</label>
							<select class="form-select <?= has_error('spp') ? 'is-invalid' : '' ?>" name="spp" id="spp">
								<option value="" hidden>Pilih Tahun ajaran</option>
								<?php foreach ($spp as $siswa) : ?>
									<option value="<?= $siswa['id_spp'] ?>" > <?= $siswa['tahun'] ?>|<?= $siswa['nominal'] ?></option>
								<?php endforeach ?>
							</select>
							<div class="invalid-feedback"><?= error('spp') ?></div>
						</div>


                  <button type="submit"name ="simpan" class="btn btn-primary">Simpan</button>
                  <a href="index.php"  class="btn btn-danger">Batal</a>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <footer>
      <!-- place footer here -->
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
      integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
      integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
