<?php
$siswa = tampil_data('siswa', 'JOIN kelas ON siswa.id_kelas=kelas.id_kelas JOIN spp ON siswa.id_spp=spp.id_spp');
?>

<div class="container my-5">
    <?= flash() ?>

    <div class="card shadow-sm">
        <div class="card-header py-3">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-0">Siswa</h4>
                </div>
                <div>
                    <a href="<?= BASE_URL . '/index.php?page=tambah_siswa' ?>" class="btn btn-light"><i class="bi bi-plus-circle"></i> Tambah Siswa</a>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead class="bg-light text-primary">
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">nisn</th>
                            <th scope="col">nis</th>
                            <th scope="col">Nama_siswa</th>
                            <th scope="col">Email</th>
                            <th scope="col">Password</th>
                            <th scope="col">Kelas</th>
                            <th scope="col">Alamat</th>
                            <th scope="col">No_telp</th>
                            <th scope="col">Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1 ?>
                        <?php foreach ($siswa as $trx) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>#<?= $trx['nisn'] ?></td>
                                <td><?= $trx['nis'] ?></td>
                                <td><?= $trx['nama_siswa'] ?></td>
                                <td><?= $trx['email'] ?></td>
                                <td><?= $trx['password'] ?></td>
                                <td><?= $trx['nama_kelas'] ?>|<?= $trx['kompetesi_keahlian'] ?></td>
                                <td><?= $trx['alamat'] ?></td>
                                <td><?= $trx['no_telp'] ?></td>
                                
                                <td>
                                    <a href="<?= BASE_URL . '/index.php?page=edit_siswa&nisn=' . $trx['nisn'] ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil"></i></a>
                                    <a href="<?= BASE_URL . '/index.php?page=hapus_siswa&nisn=' . $trx['nisn'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Ingin Menghapus Data?')"><i class="bi bi-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach ?>
                        <?php if (mysqli_num_rows($siswa) < 1) : ?>
                            <tr>
                                <td class="text-center" colspan="9">Tidak ada data!</td>
                            </tr>
                        <?php endif ?>  
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>