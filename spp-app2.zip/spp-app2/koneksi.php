<?php
// Membuat koneksi ke database
$servername = "localhost"; // Nama server database
$username = "root"; // Username database
$password = ""; // Password database
$database = "spp-app"; // Nama database

// Membuat koneksi
$conn = mysqli_connect($servername, $username, $password, $database);

// Memeriksa koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
