<?php
$admin = tampil_data('petugas');
?>

<div class="container my-5">
    <?= flash() ?>

    <div class="card shadow-sm">
        <div class="card-header py-3">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-0">admin</h4>
                </div>
                <div>
                    <a href="<?= BASE_URL . '/index.php?page=tambah_admin' ?>" class="btn btn-light"><i class="bi bi-plus-circle"></i> Tambah Transaksi</a>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead class="bg-light text-primary">
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">id_admin</th>
                            <th scope="col">username</th>
                            <th scope="col">nama_admin</th>
                            <th scope="col">Email</th>
                            <th scope="col">Password</th>
                            <th scope="col">level</th>
                            <th scope="col">Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1 ?>
                        <?php foreach ($admin as $trx) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>#<?= $trx['id_petugas'] ?></td>
                                <td><?= $trx['username'] ?></td>
                                <td><?= $trx['nama_petugas'] ?></td>
                                <td><?= $trx['email'] ?></td>
                                <td><?= $trx['password'] ?></td>
                                <td><?= $trx['level'] ?></td>
                                <td>
                                <a href="<?= BASE_URL . '/index.php?page=edit_admin&id_petugas=' . $trx['id_petugas'] ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil"></i></a>
                                    <a href="<?= BASE_URL . '/index.php?page=hapus_admin&id_petugas=' . $trx['id_petugas'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Ingin Menghapus Data?')"><i class="bi bi-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach ?>
                        <?php if (mysqli_num_rows($admin) < 1) : ?>
                            <tr>
                                <td class="text-center" colspan="9">Tidak ada data!</td>
                            </tr>
                        <?php endif ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>