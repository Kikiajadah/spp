<?php

hapus_data('petugas','id_petugas=' . $_GET['id_petugas']);

set_flash('success', 'petugas berhasil dihapus');
back();