<?php



if (isset($_POST['simpan'])) {
	
 

	$tambah = tambah_data('petugas', [
		'username' => post('nis'),
		'nama_petugas' => post('siswa'),
    'password'  => password_hash (post('pw'), PASSWORD_DEFAULT),
    'email' => post('email'),
		'level' => post('admin')
   
	]);


	set_flash('success', 'Siswa berhasil ditambahkan');
	header('Location: index.php?page=admin');
	exit;
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- Bootstrap CSS v5.2.1 -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT"
      crossorigin="anonymous"
    />
  </head>

  <body>
    
    <main>
      <div class="container mt-5 mb-5">
        <div class="row justify-content-center">
          <div class="col-lg-6">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Tambah Siswa</h4>
                <form method="POST">
                  <div class="mb-3">
                    <label for="" class="form-label">Nama petugas</label>
                    <input
                      type=text"
                      class="form-control"
                      name="siswa"
                      id="siswa"
                      aria-describedby="helpId"
                      placeholder=""
                    />
                  </div>
                  <div class="mb-3">
                    <label for="" class="form-label">username</label>
                    <input
                      type=text"
                      class="form-control"
                      name="nis"
                      id="nis"
                      aria-describedby="helpId"
                      placeholder=""
                    />
                  </div>


                  <div class="mb-3">
                    <label for="" class="form-label">email</label>
                    <input
                      type="email"
                      class="form-control"
                      name="email"
                      id="email"
                      placeholder=""
                    />
                  </div>
                  <div class="mb-3">
                    <label for="" class="form-label">password</label>
                    <input
                      type="password"
                      class="form-control"
                      name="pw"
                      id="pw"
                      placeholder=""
                    />
                  </div>
                  <div class="mb-3">
                    <label for="level" class="form-label">level</label>
							<select class="form-select <?= has_error('level') ? 'is-invalid' : '' ?>" name="admin" id="admin">
								<option value="" hidden>Pilih level</option>
								<option value="1" <?= select_old('level', last_value('level')) ?>>admin</option>
								<option value="2" <?= select_old('level', last_value('level')) ?>>pengurus</option>
							</select>
              <div class="invalid-feedback"><?= error('level') ?></div>
                  </div>
					
						

                 

                  <button type="submit"name ="simpan" class="btn btn-primary">Simpan</button>
                  <a href="index.php"  class="btn btn-danger">Batal</a>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <footer>
      <!-- place footer here -->
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
      integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
      integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
