<?php
$transaksi = tampil_data('pembayaran', 'JOIN petugas ON pembayaran.id_petugas=petugas.id_petugas JOIN siswa ON pembayaran.nisn=siswa.nisn JOIN spp ON pembayaran.id_spp=spp.id_spp');
?>
  <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead class="bg-light text-primary">
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">TRXID</th>
                            <th scope="col">Admin</th>
                            <th scope="col">Siswa</th>
                            <th scope="col">Tanggal</th>
                            <th scope="col">Bulan</th>
                            <th scope="col">Nominal</th>
                            <th scope="col">Jumlah Bayar</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1 ?>
                        <?php foreach ($transaksi as $trx) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>#<?= $trx['trxid'] ?></td>
                                <td><?= $trx['nama_petugas'] ?></td>
                                <td><?= $trx['nama_siswa'] ?></td>
                                <td><?= date('d F Y', strtotime($trx['tgl_bayar'])) ?></td>
                                <td><?= nama_bulan($trx['spp_bulan']) ?> <?= $trx['tahun'] ?></td>
                                <td>Rp<?= number_format($trx['nominal'], '0', '.', '.') ?></td>
                                <td>Rp<?= number_format($trx['jumlah_bayar'], '0', '.', '.') ?></td>
                                
                            </tr>
                        <?php endforeach ?>
                        <?php if (mysqli_num_rows($transaksi) < 1) : ?>
                            <tr>
                                <td class="text-center" colspan="9">Tidak ada data!</td>
                            </tr>
                        <?php endif ?>
                    </tbody>
                </table>
            </div>

        </div>
<script>
    window.print()
</script>