<?php

hapus_data('pembayaran', 'trxid=' . $_GET['trxid']);

set_flash('success', 'Transaksi berhasil dihapus');
back();