<div class="container">
    <div class="text-center text-primary display-6" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%)"><span class="fw-bold">503</span> | Service Unavailable</div>
</div>