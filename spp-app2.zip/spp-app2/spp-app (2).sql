-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2023 at 06:23 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spp-app`
--

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `nama_kelas` varchar(10) NOT NULL,
  `kompetesi_keahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `nama_kelas`, `kompetesi_keahlian`) VALUES
(1, 'X', 'DKV 1'),
(2, 'X', 'DKV 2'),
(3, 'X', 'DKV 3'),
(4, 'X', 'TKJ'),
(5, 'X', 'RPL 1'),
(6, 'X', 'RPL 2'),
(7, 'XI', 'MM 1'),
(8, 'XI', 'MM 2'),
(9, 'XI', 'TKJ 1'),
(10, 'XI', 'TKJ 2'),
(11, 'XI', 'RPL'),
(12, 'XII', 'MM 1'),
(13, 'XII', 'MM 2'),
(14, 'XII', 'MM 3'),
(15, 'XII', 'MM 4'),
(16, 'XII', 'TKJ 1'),
(17, 'XII', 'TKJ 2'),
(18, 'XII', 'RPL');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `trxid` varchar(50) NOT NULL,
  `id_petugas` int(11) NOT NULL,
  `nisn` int(11) NOT NULL,
  `tgl_bayar` date NOT NULL,
  `spp_bulan` int(11) NOT NULL,
  `id_spp` int(11) NOT NULL,
  `jumlah_bayar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `trxid`, `id_petugas`, `nisn`, `tgl_bayar`, `spp_bulan`, `id_spp`, `jumlah_bayar`) VALUES
(16, '390222', 3, 2147483647, '2023-03-28', 1, 6, 400000),
(17, '917781', 3, 2147483647, '2023-03-28', 11, 7, 400000),
(18, '450301', 3, 56445456, '2023-03-28', 1, 7, 400000);

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `id_petugas` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `nama_petugas` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` enum('Administrator','petugas') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `username`, `nama_petugas`, `email`, `password`, `level`) VALUES
(3, 'admin', 'admin', 'admin@gmail.com', '$2y$10$ykN50yPzEWhKiH/QIaBJceP2e7UqLoeHM1mpDxpF0iAxwcFdy0.ba', 'Administrator'),
(5, '223', '', 'admin23321@gmail.com', 'apaaja', 'Administrator'),
(6, 'dextrer', 'albert', 'alvin@gmail.com', 'yayaya', 'petugas'),
(7, 'sia', 'sia', 'sia12@gmail.com', 'sia23', 'Administrator'),
(8, 'alvinjb', 'alvin', 'alvin123@gmail.com', '$2y$10$wU7I7sX7exx5hZ4BWNWoMuQ///vgcH4j.SSm0pSVT.hW1Lplcr95q', 'petugas'),
(9, '123', 'farid', 'farid13@gmail.com', '$2y$10$UbZqlJz0f/0/hzN7ak0BHOcZREvVQrjpKzJuZ0NvlCZmmxS/le6IG', 'petugas');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `nisn` char(11) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `nama_siswa` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `pasword_nohash` varchar(100) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `id_spp` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`nisn`, `nis`, `nama_siswa`, `email`, `password`, `pasword_nohash`, `id_kelas`, `alamat`, `no_telp`, `id_spp`) VALUES
('4', '24323', '', 'alvinjeprando@gmail.com', '$2y$10$ED4rENHAGjMmj8flPxlPM.yhRQQ15IGY8fmigEAKbSeQNAi0w4QiG', '$2y$10$gitTIOXm1WN2CB72Hz0SRemFvLdLAaAbSq9Aykte5RKOf2RlHzGde', 2, 'wanaherang', '212121', 1),
('4534534', '2323', 'farel', 'alvin123@gmail.com', '$2y$10$mPs5nqb6GR63pkwRYEza4e6k/t4Ot/eNaMG6EmZDWwiMaAddxmo3O', '$2y$10$4BGRCyZFpOkssDdpoFcL6uCkG4D6rWMAOrXBmEldZ45I7eULHVdkq', 0, 'grab', '02454', 0),
('56445456', '56654654', 'sia', 'sia@gmail.com', '$2y$10$yjupfzauScCBinABkdaPf.sM8V.mGxN43nf4LjJZEAfQzyk1vRH/u', 'sia', 13, 'depok', '02104104', 6),
('6724253625', '9767544e5', 'fardan', 'fardan@gmail.com', '$2y$10$niHvExjQCTqEUQqqnWcG.O.0V3JPpL563Dzl.fpYN5s1dnLQzuX0m', 'fardan', 18, 'mekar', '05454410551', 6),
('7756565343', '5676575334', 'dexter342', 'dexter25434@gmail.com', '$2y$10$BEqdLYlPV9FVOjsgygHaHOH8s5WcDdn56cvQGbrGx09sf5S/n9whi', '$2y$10$5ypk6NPHC6ua9GcuutNqIuJua3EdTlW63z679QvgpKAipbBjTNwTy', 11, 'grand itu', '0920944200', 6);

-- --------------------------------------------------------

--
-- Table structure for table `spp`
--

CREATE TABLE `spp` (
  `id_spp` int(11) NOT NULL,
  `tahun` int(11) NOT NULL,
  `nominal` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `spp`
--

INSERT INTO `spp` (`id_spp`, `tahun`, `nominal`) VALUES
(6, 54345, 435345),
(7, 2024, 500000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`nisn`),
  ADD UNIQUE KEY `nisn` (`nis`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `spp`
--
ALTER TABLE `spp`
  ADD PRIMARY KEY (`id_spp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `spp`
--
ALTER TABLE `spp`
  MODIFY `id_spp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
